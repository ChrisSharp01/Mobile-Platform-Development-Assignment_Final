package uk.ac.csharp204caledonian.trafficreportingappv2;
// CREATED BY CHRISTOPHER DAVID SHARP - S1628368
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import gr.net.maroulis.library.EasySplashScreen;

public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EasySplashScreen config = new EasySplashScreen(SplashScreen.this)
                .withFullScreen()
                .withTargetActivity(MainActivity.class)
                .withSplashTimeOut(10000)
                .withBackgroundColor(Color.parseColor("#3F51B5"))
                .withLogo(R.mipmap.traffic)
                .withHeaderText("Welcome to C.Sharp's Traffic Reporting App")
                .withFooterText("Student ID: S1628368 - Glasgow Caledonian University")
                .withBeforeLogoText("Created Using Android Studio 3.0.1");

        config.getHeaderTextView().setTextColor(android.graphics.Color.WHITE);
        config.getFooterTextView().setTextColor(android.graphics.Color.WHITE);
        config.getBeforeLogoTextView().setTextColor(android.graphics.Color.WHITE);

        // set to view
        View view = config.create();

        // set view to content view
        setContentView(view);

    }


}
