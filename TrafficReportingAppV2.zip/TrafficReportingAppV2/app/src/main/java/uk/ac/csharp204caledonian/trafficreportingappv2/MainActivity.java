package uk.ac.csharp204caledonian.trafficreportingappv2;
// CREATED BY CHRISTOPHER DAVID SHARP - S1628368
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private Button MASubmit;
    private DatePicker MAdaySpinner;
    private TextView MALabel;
    private TextView MAStartLabel;
    private ListView MAListView;
    private Button MAincidentsButton;
    private Button MAroadworksButton;
    private SwipeRefreshLayout MASwipeLayout;
    private TextView MAFeedTitleTextView;
    private String MAFeedTitle;

    ArrayList<String> MATitleList;
    ArrayList<String> MADescriptionList;
    ArrayList<String> MATitleDescriptionList;
    ArrayList<String> MASelectedWorksList = new ArrayList<String>();
    ArrayList<Date> startDateList = new ArrayList<Date>();
    ArrayList<Date> endDateList = new ArrayList<Date>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MASubmit = findViewById(R.id.submitButton);
        MAdaySpinner = findViewById(R.id.daySpinner);
        MALabel = findViewById(R.id.Label);
        MAStartLabel = findViewById(R.id.StartLabel);
        MAListView = findViewById(R.id.listView);
        MAincidentsButton = findViewById(R.id.incidentsButton);
        MAroadworksButton = findViewById(R.id.roadworksButton);
        MASwipeLayout = findViewById(R.id.swipeRefreshLayout);
        MAFeedTitleTextView = findViewById(R.id.feedTitle);
        MATitleList = new ArrayList<String>();
        MADescriptionList = new ArrayList<String>();
        MATitleDescriptionList = new ArrayList<String>();

        //HIDING UI ELEMENTS WHICH ARE NOT FUNCTIONAL UNTIL DATA IS LOADED
        MAdaySpinner.setVisibility(View.INVISIBLE);
        MALabel.setVisibility(View.INVISIBLE);
        MASubmit.setVisibility(View.INVISIBLE);
        RelativeLayout.LayoutParams Lparams =
                new RelativeLayout.LayoutParams
                        (ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        Lparams.addRule(RelativeLayout.BELOW, R.id.feedTitle);
        MASwipeLayout.setLayoutParams(Lparams);

        //DISABLING MANUAL DATE ENTRY
        MAdaySpinner.setDescendantFocusability(DatePicker.FOCUS_BLOCK_DESCENDANTS);

        MAincidentsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Execute RSS Incidents feed class, hide elements not required and move view up
                new FetchIncidentsTask().execute();
                MAdaySpinner.setVisibility(View.INVISIBLE);
                MALabel.setVisibility(View.INVISIBLE);
                MAStartLabel.setVisibility(View.INVISIBLE);
                MASubmit.setVisibility(View.INVISIBLE);
                RelativeLayout.LayoutParams Lparams =
                        new RelativeLayout.LayoutParams
                                (ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                Lparams.addRule(RelativeLayout.BELOW, R.id.feedTitle);
                MASwipeLayout.setLayoutParams(Lparams);
            }
        });

        MAroadworksButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Execute RSS Roadworks feed class, show elements used for this feature and move view down
                new FetchRoadWorksTask().execute();
                MAStartLabel.setVisibility(View.INVISIBLE);
                MAdaySpinner.setVisibility(View.VISIBLE);
                MALabel.setVisibility(View.VISIBLE);
                MASubmit.setVisibility(View.VISIBLE);
                RelativeLayout.LayoutParams Lparams =
                        new RelativeLayout.LayoutParams
                                (ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                Lparams.addRule(RelativeLayout.BELOW, R.id.submitButton);
                MASwipeLayout.setLayoutParams(Lparams);
            }
        });

        MASubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Execute RSS Roadworks By Date feed class
                MAListView.setAdapter(null);
                new FetchRoadWorksByDateTask().execute();
            }
        });

        MASwipeLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                //Refresh screen depending on which feed is being viewed
                if  (MAFeedTitle.equals("Traffic Scotland - Current Incidents")) {
                    new FetchIncidentsTask().execute();
                }else{

                }
            }
        });
    }

    public InputStream getInputStream(URL url) {
    //OPENING INTERNET CONNECTION
        try {
            return url.openConnection().getInputStream();
        } catch (IOException e) {
            return null;
        }
    }

    public class FetchIncidentsTask extends AsyncTask<Integer, Void, Exception> {

        ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);
        Exception exception = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            MATitleList.clear(); //Clearing lists
            MADescriptionList.clear();
            MATitleDescriptionList.clear();
            MAListView.setAdapter(null); //Clearing View
            MASwipeLayout.setRefreshing(false);
            MAFeedTitle = "Traffic Scotland - Current Incidents";
            MAFeedTitleTextView.setText("Feed Title: " + MAFeedTitle);
            progressDialog.setMessage("Feed is loading, please wait...");
            progressDialog.show();
        }

        @Override
        protected Exception doInBackground(Integer... integers) {

            try {
                URL url = new URL("http://www.trafficscotland.org/rss/feeds/currentincidents.aspx");

                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(false);
                XmlPullParser XPP = factory.newPullParser();
                XPP.setInput(getInputStream(url), "iso-8859-1");

                boolean isItem = false; // BOOLEAN TO IDENTIFY THE XML <Item> ELEMENT
                int eventType = XPP.getEventType();

                //WHILE LOOP TO READ THE XML DOCUMENT
                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        if (XPP.getName().equalsIgnoreCase("item")) {
                            isItem = true; //ITEM IDENTIFIED
                        } else if (XPP.getName().equalsIgnoreCase("title")) {
                            if (isItem) {
                                String title = XPP.nextText();
                                //ADDING TITLE TO LISTS
                                MATitleList.add(title);
                                MATitleDescriptionList.add(title);
                            }
                        } else if (XPP.getName().equalsIgnoreCase("description")) {
                            if (isItem) {
                                String description = XPP.nextText();
                                String endItem =
                                        "-----------------------End of Item------------------------";
                                //ADDING DESCRIPTION TO LISTS
                                MADescriptionList.add(description);
                                MATitleDescriptionList.add(description);
                                MATitleDescriptionList.add(endItem);
                            }
                        }
                    } else if (eventType ==
                            XmlPullParser.END_TAG && XPP.getName().equalsIgnoreCase("item")) {
                        isItem = false;
                    }
                    eventType = XPP.next();
                }
            } catch (MalformedURLException e) {
                exception = e;
            } catch (XmlPullParserException e) {
                exception = e;
            } catch (IOException e) {
                exception = e;
            }
            return exception;
        }

        @Override
        protected void onPostExecute(Exception ex) {
            super.onPostExecute(ex);

            if(MATitleDescriptionList != null) {
                //APPLYING LISTVIEW ADAPTER TO LIST
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(MainActivity.this,
                                android.R.layout.simple_list_item_1, MATitleDescriptionList);

                //DISPLAY LIST
                MAListView.setAdapter(adapter);
            }else{
                //IF THERE ARE NO INCIDENTS SHOW A MESSAGE
                Toast.makeText(MainActivity.this, "THERE ARE NO CURRENT INCIDENTS",
                        Toast.LENGTH_LONG).show();
            }
            progressDialog.dismiss();
        }
    }

    public class FetchRoadWorksTask extends AsyncTask<Integer, Void, Exception> {

        ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);

        Exception exception = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            MATitleList.clear(); //Clearing lists
            MADescriptionList.clear();
            MATitleDescriptionList.clear();
            MAListView.setAdapter(null); //Clearing View
            MASwipeLayout.setRefreshing(false);
            MAFeedTitle = "Traffic Scotland - Planned Roadworks";
            MAFeedTitleTextView.setText("Feed Title: " + MAFeedTitle);
            progressDialog.setMessage("Feed is loading, please wait...");
            progressDialog.show();
        }

        @Override
        protected Exception doInBackground(Integer... integers) {

            try {
                URL url = new URL("http://www.trafficscotland.org/rss/feeds/plannedroadworks.aspx");

                XmlPullParserFactory factory = XmlPullParserFactory.newInstance(); //INSTANTIATE XML PULL PARSER
                factory.setNamespaceAware(false);
                XmlPullParser XPP = factory.newPullParser();
                XPP.setInput(getInputStream(url), "iso-8859-1");

                boolean isItem = false;
                int eventType = XPP.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        if (XPP.getName().equalsIgnoreCase("item")) {
                            isItem = true;
                        } else if (XPP.getName().equalsIgnoreCase("title")) {
                            if (isItem) {
                                String title = XPP.nextText();
                                MATitleList.add(title);
                                MATitleDescriptionList.add(title);
                            }
                        } else if (XPP.getName().equalsIgnoreCase("description")) {
                            if (isItem) {
                                String description = XPP.nextText();
                                String startDateString = "";
                                String endDateString = "";

                                //PATTERN MATCHING TO FIND START DATE
                                Pattern startpatt =
                                        Pattern.compile("(Start Date: (\\w+), [0-9]{1,2} [a-zA-Z]{3,9} [0-9]{4} )");
                                Matcher startmatcher = startpatt.matcher(description);
                                if (startmatcher.find())
                                {
                                    //REMOVE UNWANTED CHARACTERS AND DAY NAME
                                    startDateString = (startmatcher.group(1));
                                    startDateString =
                                            startDateString.replaceAll("(Start Date: (\\w+), )", "");
                                    startDateString =
                                            startDateString.replaceAll("( $)", "");
                                    startDateString = startDateString.replaceAll(" ", "/");
                                }

                                //PATTERN MATCHING TO FIND END DATE
                                Pattern endpatt = Pattern.compile("(End Date: (\\w+), [0-9]{1,2} [a-zA-Z]{3,9} [0-9]{4} )");
                                Matcher endmatcher = endpatt.matcher(description);
                                if (endmatcher.find())
                                {
                                    //REMOVE UNWANTED CHARACTERS AND DAY NAME
                                    endDateString = (endmatcher.group(1));
                                    endDateString =
                                            endDateString.replaceAll("(End Date: (\\w+), )", "");
                                    endDateString = endDateString.replaceAll("( $)", "");
                                    endDateString = endDateString.replaceAll(" ", "/");
                                }

                                //START DATE FORMATTING
                                DateFormat startFormatter = new SimpleDateFormat("dd/MMM/yyyy");
                                Date startDate = null;
                                try {
                                    startDate = startFormatter.parse(startDateString);
                                } catch (java.text.ParseException e) {
                                    e.printStackTrace();
                                }

                                //END DATE FORMATTING
                                DateFormat endFormatter = new SimpleDateFormat("dd/MMM/yyyy");
                                Date endDate = null;
                                try {
                                    endDate = endFormatter.parse(endDateString);
                                } catch (java.text.ParseException e) {
                                    e.printStackTrace();
                                }

                                //DESCRIPTION FORMATTING
                                description =
                                        description.replaceAll("<br />", "\n");;
                                description =
                                        description.replaceAll("(Start Date: (\\w+),)", "Start Date:");
                                description =
                                        description.replaceAll("(End Date: (\\w+),)", "End Date:");
                                String endItem = "-----------------------End of Item------------------------";

                                MADescriptionList.add(description);
                                MATitleDescriptionList.add(description);
                                MATitleDescriptionList.add(endItem);

                                // ADDING START AND END DATES TO LISTS
                                startDateList.add(startDate);
                                endDateList.add(endDate);
                            }
                        }
                    } else if (eventType ==
                            XmlPullParser.END_TAG && XPP.getName().equalsIgnoreCase("item")) {
                        isItem = false;
                    }
                    eventType = XPP.next();
                }
            } catch (MalformedURLException e) {
                exception = e;
            } catch (XmlPullParserException e) {
                exception = e;
            } catch (IOException e) {
                exception = e;
            }
            return exception;
        }

        @Override
        protected void onPostExecute(Exception ex) {
            super.onPostExecute(ex);

            ArrayAdapter<String> adapter =
                    new ArrayAdapter<String>(MainActivity.this,
                            android.R.layout.simple_list_item_1, MATitleDescriptionList);

            MAListView.setAdapter(adapter);
            progressDialog.dismiss();
        }
    }

    public class FetchRoadWorksByDateTask extends AsyncTask<Integer, Void, Exception> {

        ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);

        Exception exception = null;

        int day;
        int month;
        int year;
        String dayString;
        String monthString;
        String yearString;
        String[] months =
                {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        String dateString;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            MASelectedWorksList.clear(); //Clearing selected roadworks list
            MAListView.setAdapter(null); //Clearing View
            MASwipeLayout.setRefreshing(false);
            MAFeedTitle = "Traffic Scotland - Selected Roadworks";
            MAFeedTitleTextView.setText("Feed Title: " + MAFeedTitle);
            progressDialog.setMessage("Roadworks loading, please wait...");
            progressDialog.show();
            MASelectedWorksList.clear();
        }

        @Override
        protected Exception doInBackground(Integer... integers) {
        //GETTING DATE SELECTED BY USER
            day = MAdaySpinner.getDayOfMonth();
            month = MAdaySpinner.getMonth();
            year = MAdaySpinner.getYear();
            dayString = String.valueOf(day);
            //CONVERTING NUMBERS TO MONTH SHORT-NAMES
            if (month >= 0 && month <= 11) {
               monthString = String.format(months[month]);
            } else {
                return exception;
            }
            yearString = String.valueOf(year);
            //FORMATTING DATE
            dateString = dayString + "/" + monthString + "/" + yearString;
            DateFormat dateStringFormatter = new SimpleDateFormat("dd/MMM/yyyy");
            Date selectedDate = null;
            try {
                selectedDate = dateStringFormatter.parse(dateString);
            } catch (java.text.ParseException e) {
                e.printStackTrace();
            }

            List<Integer> startIndexList = new ArrayList<Integer>();
            List<Integer> endIndexList = new ArrayList<Integer>();

            //FIND THE INDEX OF ALL START DATES WHICH ARE AFTER THE SELECTED DATE AND ADD TO A LIST
            int i = 0;
            for(Date sDate : startDateList) {
                if (selectedDate.after(sDate)) {
                    startDateList.get(i);
                    startIndexList.add(i);
                }
                i ++;
            }

            //FIND THE INDEX OF ALL END DATES WHICH ARE BEFORE THE SELECTED DATE AND ADD TO A LIST
            int i2 = 0;
            for(Date eDate : endDateList) {
                if (selectedDate.before(eDate)) {
                    endDateList.get(i2);
                    endIndexList.add(i2);
                }
                i2 ++;
            }

            /*///////////////////////
            CREATE A NEW LIST WHICH CONTAINS ONLY INDEX NUMBERS WHICH APPEAR ON BOTH INDEX LISTS
            LOGICALLY THE USER SELECTED DATE IS ALWAYS BETWEEN START AND END DATES CONTAINED IN THE
            DESCRIPTION LIST WHERE THE INDEX NUMBER MATCHES THOSE ON THE commonIndexes LIST
            ///////////////////////*/
            List<Integer> commonIndexes = new ArrayList<Integer>();
            commonIndexes.addAll(startIndexList);
            commonIndexes.retainAll(endIndexList);

            String endItem =
                    "-----------------------End of Item------------------------";
            for (int i3=0; i3<commonIndexes.size(); i3++) {
                for (int i4=0; i4<MATitleList.size(); i4++){
                    //MATCHING THE INDEX NUMBER TO THE INDEX OF THE LIST OF TITLES
                    //AND ADDING TO LIST
                    if(commonIndexes.get(i3) == i4){
                        MASelectedWorksList.add(MATitleList.get(i4));
                        if(MASelectedWorksList != null) {
                            for (int i5 = 0; i5 < MADescriptionList.size(); i5++) {
                                //MATCHING THE INDEX NUMBER TO THE INDEX OF THE LIST OF DESCRIPTIONS
                                //AND ADDING TO LIST
                                if (i4 == i5) {
                                    MASelectedWorksList.add(MADescriptionList.get(i5));
                                    MASelectedWorksList.add(endItem);
                                }
                            }
                        }else{
                            //IF THERE ARE NO ROADWORKS SHOW A MESSAGE
                            Toast.makeText(MainActivity.this, "THERE ARE NO ROADWORKS ON THIS DATE",
                                    Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Exception ex) {
            super.onPostExecute(ex);
            if(MASelectedWorksList != null) {
                ArrayAdapter<String> adapter =
                        new ArrayAdapter<String>(MainActivity.this,
                                android.R.layout.simple_list_item_1, MASelectedWorksList);
                MAListView.setAdapter(adapter);
            }else{
                //IF THERE ARE NO ROADWORKS SHOW A MESSAGE
                Toast.makeText(MainActivity.this, "THERE ARE NO ROADWORKS ON THIS DATE",
                        Toast.LENGTH_LONG).show();
            }
            progressDialog.dismiss();
        }
    }
}
